from datetime import date, time

class Event:
    EVENT_TYPES = ('Movie', 'Sports', 'Concert')

    def __init__(self, EventName="", EventDate=None, EventTime=None, VenueName="", TotalSeats=0, TicketPrice=0.0, EventType=""):
        self._event_name = EventName
        self._event_date = EventDate
        self._event_time = EventTime
        self._venue_name = VenueName
        self._total_seats = TotalSeats
        self._available_seats = TotalSeats
        self._ticket_price = TicketPrice
        if EventType in self.EVENT_TYPES:
            self._event_type = EventType
        else:
            raise ValueError("Invalid event type")
        self.bookings = []
    @property
    def event_name(self):
        return self._event_name

    @event_name.setter
    def event_name(self, value):
        self._event_name = value

    @property
    def event_date(self):
        return self._event_date

    @event_date.setter
    def event_date(self, value):
        self._event_date = value

    @property
    def event_time(self):
        return self._event_time

    @event_time.setter
    def event_time(self, value):
        self._event_time = value

    @property
    def venue_name(self):
        return self._venue_name

    @venue_name.setter
    def venue_name(self, value):
        self._venue_name = value

    @property
    def total_seats(self):
        return self._total_seats

    @total_seats.setter
    def total_seats(self, value):
        self._total_seats = value

    @property
    def available_seats(self):
        return self._available_seats

    @available_seats.setter
    def available_seats(self, value):
        self._available_seats = value

    @property
    def ticket_price(self):
        return self._ticket_price

    @ticket_price.setter
    def ticket_price(self, value):
        self._ticket_price = value

    @property
    def event_type(self):
        return self._event_type

    @event_type.setter
    def event_type(self, value):
        if value in self.EVENT_TYPES:
            self._event_type = value
        else:
            raise ValueError("Invalid event type")
    def calculate_total_revenue(self):
        return self._total_seats * self._ticket_price
    def get_booked_no_of_tickets(self):
        return self._total_seats - self._available_seats
    def book_tickets(self, num_tickets):
        if num_tickets <= self._available_seats:
            self._available_seats -= num_tickets
            print(f"Successfully booked {num_tickets} tickets for {self._event_name}")
        else:
            print("Insufficient available seats")
    def cancel_booking(self, num_tickets):
        if num_tickets <= self._total_seats - self._available_seats:
            self._available_seats += num_tickets
            print(f"Successfully canceled booking for {num_tickets} tickets for {self._event_name}")
        else:
            print("Invalid number of tickets to cancel")
    def display_event_details(self):
        print(f"Event Name: {self._event_name}")
        print(f"Event Date: {self._event_date}")
        print(f"Event Time: {self._event_time}")
        print(f"Venue Name: {self._venue_name}")
        print(f"Total Seats: {self._total_seats}")
        print(f"Available Seats: {self._available_seats}")
        print(f"Ticket Price: {self._ticket_price}")
        print(f"Event Type: {self._event_type}")
event = Event("Movie Night", date(2024, 2, 10), time(18, 30), "Cinema Hall", 100, 10.50, "Movie")
event.display_event_details()
event.book_tickets(5)
event.cancel_booking(2)
print(f"Total Revenue: ${event.calculate_total_revenue()}")
print(f"Total Booked Tickets: {event.get_booked_no_of_tickets()}")


