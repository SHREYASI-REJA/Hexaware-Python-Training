class Customers:
    def __init__(self, CustomerName, Email, PhoneNumber):
        self._customer_name = CustomerName
        self._email = Email
        self._phone_number = PhoneNumber

    @property
    def customer_name(self):
        return self._customer_name

    @customer_name.setter
    def customer_name(self, value):
        self._customer_name = value

    @property
    def email(self):
        return self._email

    @email.setter
    def email(self, value):
        self._email = value

    @property
    def phone_number(self):
        return self._phone_number

    @phone_number.setter
    def phone_number(self, value):
        self._phone_number = value

    def display_customer_details(self):
        print(f"Customer Name: {self._customer_name}")
        print(f"Email: {self._email}")
        print(f"Phone Number: {self._phone_number}")