class Account:
    def __init__(self, AccountID, AccountType, Balance):
        self.account_number = AccountID
        self.account_type = AccountType
        self.account_balance = Balance

    def get_account_number(self):
        return self.account_number

    def set_account_number(self, account_number):
        self.account_number = account_number

    def get_account_type(self):
        return self.account_type

    def set_account_type(self, account_type):
        self.account_type = account_type

    def get_account_balance(self):
        return self.account_balance

    def set_account_balance(self, account_balance):
        self.account_balance = account_balance

    def deposit(self, amount):
        if amount > 0:
            self.account_balance += amount
            print(f"Deposited ${amount:.2f} into the account. New balance: ${self.account_balance:.2f}")
        else:
            print("Invalid deposit amount. Please enter a positive value.")

    def withdraw(self, amount):
        if amount > 0:
            if amount <= self.account_balance:
                self.account_balance -= amount
                print(f"Withdrew ${amount:.2f} from the account. New balance: ${self.account_balance:.2f}")
            else:
                print("Insufficient funds. Withdrawal failed.")
        else:
            print("Invalid withdrawal amount. Please enter a positive value.")

    def calculate_interest(self):
        interest_rate = 4.5
        interest_amount = (self.account_balance * interest_rate) / 100
        print(f"Interest calculated at {interest_rate}%: ${interest_amount:.2f}")
        return interest_amount


