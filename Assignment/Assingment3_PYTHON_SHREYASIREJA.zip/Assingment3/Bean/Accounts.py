import email

from Assingment3.Classes.Customers import Customers



class Account(Customers):
    def __init__(self, account_num: int, AccountType: str, Balance: float, lastAccNo=None, CustomerID=None,
                 LastName=None, Email=None, FirstName=None, Phone=None):
        super().__init__(CustomerID, FirstName, LastName, email, Phone)
        self.account_num = account_num
        self.account_type = AccountType
        self.balance = Balance
        self.lastAccNo = lastAccNo

    @property
    def accountNum(self):
        return self.account_num

    @property
    def accountType(self):
        return self.account_type

    @property
    def balance(self):
        return self.balance

    @property
    def lastAccNo(self):
        return self.lastAccNo

    @accountNum.setter
    def accountNum(self, accountNum):
        self.account_num = accountNum

    @accountType.setter
    def accountType(self, type):
        self.account_type = type

    @balance.setter
    def balance(self, bal):
        self.balance = bal

    @lastAccNo.setter
    def lastAccNo(self, lastAccNo):
        self.lastAccNo = lastAccNo

    def getAccountDetails(self):
        print("Account Details: ")
        print(f"Account Number: {self.account_num}")
        print(f"Account Type: {self.account_type}")
        print(f"Customer ID: {self.customerID}")
        print(f"Customer Name: {self.firstName} {self.lastName}")
        print(f"Balance: {self.balance}")

    def depositAmount(self, amount):
        if amount > 0:
            self.balance += amount
            return self.balance
        else:
            return "Invalid"

    def withdrawAmount(self, amount):
        if amount > self.balance:
            return "Insufficient Balance"
        else:
            self.balance -= amount
            return self.balance

