class Customers:
    def __init__(self, CustomerID: int, FirstName: str, LastName: str, Email: str, Phone: str, Address: str):
        self.customerID = CustomerID
        self.firstName = FirstName
        self.lastName = LastName
        self.email = Email
        self.phone = Phone
        self.address = Address

    @property
    def customerID(self):
        return self.customerID

    @property
    def firstName(self):
        return self.firstName

    @property
    def lastName(self):
        return self.lastName

    @property
    def email(self):
        return self.email

    @property
    def phone(self):
        return self.phone

    @property
    def address(self):
        return self.address

    @customerID.setter
    def customerID(self, customerID):
        self.customerID = customerID

    @firstName.setter
    def firstName(self, firstName):
        self.firstName = firstName

    @lastName.setter
    def lastName(self, lastName):
        self.lastName = lastName

    @email.setter
    def email(self, email):
        self.email = email

    @phone.setter
    def phone(self, phone):
        self.phone = phone

    @address.setter
    def address(self, address):
        self.address = address

    def getCustomerDetails(self):
        print("Customer Details: ")
        print(f"ID: {self.customerID}")
        print(f"Name: {self.firstName} {self.lastName}")
        print(f"Email: {self.email}")
        print(f"Phone: {self.phone}")
        print(f"Address: {self.address}")


