def validate_password(password):
    if len(password) < 8:
        return "Password must be at least 8 characters long."

    if not any(char.isupper() for char in password):
        return "Password must contain at least one uppercase letter."

    if not any(char.isdigit() for char in password):
        return "Password must contain at least one digit."

    return "Password is valid."

user_password = input("Create your bank account password: ")

result_message = validate_password(user_password)
print(result_message)
