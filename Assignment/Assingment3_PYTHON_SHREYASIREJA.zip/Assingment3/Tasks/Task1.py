def check_loan_eligibility(credit_score, annual_income):
    credit_score_threshold = 700
    annual_income_threshold = 50000

    if credit_score > credit_score_threshold and annual_income >= annual_income_threshold:
        return "Congratulations! You are eligible for a loan."
    else:
        return "Sorry, you are not eligible for a loan."

customer_credit_score = int(input("Enter your credit score: "))
customer_annual_income = float(input("Enter your annual income: $"))

result = check_loan_eligibility(customer_credit_score, customer_annual_income)
print(result)
