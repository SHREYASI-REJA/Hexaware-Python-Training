transaction_history = []

def display_transaction_history():
    print("\nTransaction History:")
    for i, transaction in enumerate(transaction_history, start=1):
        print(f"{i}. {transaction}")

while True:
    print("\nOptions:")
    print("1. Deposit")
    print("2. Withdraw")
    print("3. Exit")

    choice = input("Enter your choice (1/2/3): ")

    if choice == '1':
        deposit_amount = float(input("Enter the deposit amount: $"))
        transaction_history.append(f"Deposit: +${deposit_amount:.2f}")

    elif choice == '2':
        withdrawal_amount = float(input("Enter the withdrawal amount: $"))
        transaction_history.append(f"Withdrawal: -${withdrawal_amount:.2f}")

    elif choice == '3':
        display_transaction_history()
        print("Exiting the program.")
        break

    else:
        print("Invalid choice. Please enter a valid option.")


