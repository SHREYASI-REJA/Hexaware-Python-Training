def atm_transaction(balance):
    print("1. Check Balance")
    print("2. Withdraw")
    print("3. Deposit")

    option = int(input("Enter your choice (1/2/3): "))

    if option == 1:
        print(f"Your current balance: ${balance}")

    elif option == 2:
        withdrawal_amount = int(input("Enter the amount to withdraw: $"))

        if withdrawal_amount > balance:
            print("Insufficient funds. Withdrawal failed.")
        elif withdrawal_amount % 100 != 0 or withdrawal_amount % 500 != 0:
            print("Withdrawal amount must be in multiples of 100 or 500. Withdrawal failed.")
        else:
            balance -= withdrawal_amount
            print(f"Withdrawal successful. Remaining balance: ${balance}")

    elif option == 3:
        deposit_amount = int(input("Enter the amount to deposit: $"))
        balance += deposit_amount
        print(f"Deposit successful. Updated balance: ${balance}")

    else:
        print("Invalid option. Please choose a valid option (1/2/3).")

initial_balance = float(input("Enter your current balance: $"))

atm_transaction(initial_balance)
