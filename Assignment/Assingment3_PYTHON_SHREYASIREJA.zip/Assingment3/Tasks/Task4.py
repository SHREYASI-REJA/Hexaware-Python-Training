customer_accounts = {
    '12345': 1000.50,
    '56789': 5000.25,
    '98765': 750.80
}

def check_account_balance(account_number):

    if account_number in customer_accounts:
        return customer_accounts[account_number]
    else:
        return None

while True:

    account_number = input("Enter your account number (or 'exit' to quit): ")

    if account_number.lower() == 'exit':
        print("Exiting the program.")
        break

    balance = check_account_balance(account_number)
    if balance is not None:
        print(f"Account balance for account {account_number}: ${balance:.2f}")
        break
    else:
        print("Invalid account number. Please try again.")
