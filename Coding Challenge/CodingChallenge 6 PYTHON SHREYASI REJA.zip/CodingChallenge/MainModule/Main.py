from CodingChallenge.Connection.DBUtil import DBUtil

class OrderManagement:
    def __init__(self):
        self.db_util = DBUtil(host='localhost', user='root', password='Root', port='3306', database='OrderManagementSystem')

    def main(self):
        while True:
            print("\nMenu:")
            print("1. Create User")
            print("2. Create Product")
            print("3. Cancel Order")
            print("4. Get All Products")
            print("5. Get Order by User")
            print("6. Exit")

            choice = input("Enter your choice: ")

            if choice == '1':
                self.createUser()
            elif choice == '2':
                self.createProduct()
            elif choice == '3':
                self.cancelOrder()
            elif choice == '4':
                self.getAllProducts()
            elif choice == '5':
                self.getOrderByUser()
            elif choice == '6':
                print("Exiting...")
                break
            else:
                print("Invalid choice. Please try again.")

    def createUser(self):
        userId = int(input("Enter userId: "))
        username = input("Enter username: ")
        password = input("Enter password: ")
        role = input("Enter role (Admin/User): ")

        query = f"INSERT INTO User (userId, username, password, role) VALUES ({userId}, '{username}', '{password}', '{role}')"
        self.db_util.execute_query(query)
        print("User created successfully.")

    def createProduct(self):
        productId = int(input("Enter productId: "))
        productName = input("Enter productName: ")
        description = input("Enter description: ")
        price = float(input("Enter price: "))
        quantityInStock = int(input("Enter quantityInStock: "))
        productType = input("Enter type (Electronics/Clothing): ")

        query = f"INSERT INTO Product (productId, productName, description, price, quantityInStock, type) VALUES ({productId}, '{productName}', '{description}', {price}, {quantityInStock}, '{productType}')"
        self.db_util.execute_query(query)
        print("Product created successfully.")

    def cancelOrder(self):
        orderId = int(input("Enter orderId: "))
        userId = int(input("Enter userId: "))

        query = f"DELETE FROM Orders WHERE orderId = {orderId} AND userId = {userId}"
        self.db_util.execute_query(query)
        print("Order canceled successfully.")

    def getAllProducts(self):
        query = "SELECT * FROM Product"
        products = self.db_util.fetch_all(query)
        print("All Products:")
        for product in products:
            print(product)

    def getOrderByUser(self):
        userId = int(input("Enter userId: "))

        query = f"SELECT * FROM Orders WHERE userId = {userId}"
        user_orders = self.db_util.fetch_all(query)
        if user_orders:
            print("Orders for user:")
            for order in user_orders:
                print(order)
        else:
            print("No orders found for the user.")

if __name__ == "__main__":
    order_management = OrderManagement()
    order_management.main()
