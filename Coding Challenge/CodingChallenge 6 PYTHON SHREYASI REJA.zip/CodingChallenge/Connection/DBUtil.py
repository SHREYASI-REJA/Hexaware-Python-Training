from mysql.connector import connect


class DBUtil:
    def __init__(self, host, user, password, port, database):
        self.connection = connect(
            host=host,
            user=user,
            password=password,
            port=port,
            database=database
        )
        self.cursor = self.connection.cursor()

    def execute_query(self, query, values=None):
        try:
            self.cursor.execute(query, values)
            self.connection.commit()
            self.cursor.fetchall()
        except Exception as e:
            print(f"Query Execution Error! {e}")
            self.connection.rollback()

    def fetch_one(self, query, values=None):
        try:
            self.cursor.execute(query, values)
            result = self.cursor.fetchone()
            return result
        except Exception as e:
            print(f"FetchOne Error: {e}")
            self.connection.rollback()
            return None

    def close_connection(self):
        self.cursor.close()
        self.connection.close()

class UserNotFound(Exception):
    pass

class OrderNotFound(Exception):
    pass

from CodingChallenge.Service.IOrderManagementRepository import IOrderManagementRepository


class OrderProcessor(IOrderManagementRepository):
    def __init__(self):

        self.db_util = {}
        self.users_database = {}
        self.orders_database = {}
        self.products_database = {}
        self.admin_user = None

    def createOrder(self, user, products):
        if user.userId not in self.users_database:
            self.createUser(user)
        order_id = len(self.orders_database) + 1
        self.orders_database[order_id] = {'userId': user.userId, 'products': products}
        return order_id

    def cancelOrder(self, userId, orderId):
        if userId not in self.users_database:
            raise UserNotFound("User not found in the database.")
        if orderId not in self.orders_database:
            raise OrderNotFound("Order not found in the database.")
        del self.orders_database[orderId]

    def createProduct(self, adminUser, product):
        if adminUser != self.admin_user:
            raise UserNotFound("Admin user not found in the database.")
        product_id = len(self.products_database) + 1
        self.products_database[product_id] = product
        return product_id

    def createUser(self, user):
        self.users_database[user.userId] = user

    def getAllProducts(self):
        return list(self.products_database.values())

    def getOrderByUser(self, user):
        user_orders = [order for order in self.orders_database.values() if order['userId'] == user.userId]
        return user_orders


