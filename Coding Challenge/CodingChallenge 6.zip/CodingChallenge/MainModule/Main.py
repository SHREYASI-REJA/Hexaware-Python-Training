
class OrderManagement:
    def __init__(self, order_processor):
        self.order_processor = order_processor


    def main(self):
        db_util = DBUtil(host='localhost', user='root', password='Krishna@128', port='3306', database='TechShop')

        while True:
            print("\nMenu:")
            print("1. Create User")
            print("2. Create Product")
            print("3. Cancel Order")
            print("4. Get All Products")
            print("5. Get Order by User")
            print("6. Exit")

            choice = input("Enter your choice: ")

            if choice == '1':
                self.createUser()
            elif choice == '2':
                self.createProduct()
            elif choice == '3':
                self.cancelOrder()
            elif choice == '4':
                self.getAllProducts()
            elif choice == '5':
                self.getOrderByUser()
            elif choice == '6':
                print("Exiting...")
                break
            else:
                print("Invalid choice. Please try again.")

    def createUser(self):
        userId = int(input("Enter userId: "))
        username = input("Enter username: ")
        password = input("Enter password: ")
        role = input("Enter role (Admin/User): ")

        user = {'userId': userId, 'username': username, 'password': password, 'role': role}
        self.order_processor.create_user(user)
        print("User created successfully.")

        query = f"INSERT INTO User (userId, username, password, role) VALUES ({userId}, '{username}', '{password}', '{role}')"
        print("SQL Query for User Insertion:", query)

    def createProduct(self):
        # Assume product details are taken as input
        productId = int(input("Enter productId: "))
        productName = input("Enter productName: ")
        description = input("Enter description: ")
        price = float(input("Enter price: "))
        quantityInStock = int(input("Enter quantityInStock: "))
        productType = input("Enter type (Electronics/Clothing): ")

        product = {'productId': productId, 'productName': productName, 'description': description,
                   'price': price, 'quantityInStock': quantityInStock, 'productType': productType}
        self.order_processor.create_product(product)
        print("Product created successfully.")

        query = f"INSERT INTO Product (productId, productName, description, price, quantityInStock, type) VALUES ({productId}, '{productName}', '{description}', {price}, {quantityInStock}, '{productType}')"
        print("SQL Query for Product Insertion:", query)

    def cancelOrder(self):
        orderId = int(input("Enter orderId: "))
        userId = int(input("Enter userId: "))

        try:
            self.order_processor.cancel_order(userId, orderId)
            print("Order canceled successfully.")
        except :
            print("Order not found.")

        query = f"DELETE FROM Orders WHERE orderId = {orderId} AND userId = {userId}"
        print("SQL Query for Cancel Order:", query)

    def getAllProducts(self):
        products = self.order_processor.get_all_products()
        print("All Products:")
        for product in products:
            print(product)

        query = "SELECT * FROM Product"
        print("SQL Query for Get All Products:", query)

    def getOrderByUser(self):
        userId = int(input("Enter userId: "))

        user_orders = self.order_processor.get_order_by_user(userId)
        if user_orders:
            print("Orders for user:")
            for order in user_orders:
                print(order)
        else:
            print("No orders found for the user.")

        query = f"SELECT * FROM Orders WHERE userId = {userId}"
        print("SQL Query for Get Order by User:", query)

    def getdbconnection(self):
        pass






