class Product:
    def __init__(self, productId, productName, description, price, quantityInStock, productType):
        self._productId = productId
        self._productName = productName
        self._description = description
        self._price = price
        self._quantityInStock = quantityInStock
        self._productType = productType

    @property
    def productId(self):
        return self._productId

    @productId.setter
    def productId(self, value):
        self._productId = value

    @property
    def productName(self):
        return self._productName

    @productName.setter
    def productName(self, value):
        self._productName = value

    @property
    def description(self):
        return self._description

    @description.setter
    def description(self, value):
        self._description = value

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        self._price = value

    @property
    def quantityInStock(self):
        return self._quantityInStock

    @quantityInStock.setter
    def quantityInStock(self, value):
        self._quantityInStock = value

    @property
    def productType(self):
        return self._productType

    @productType.setter
    def productType(self, value):
        self._productType = value


class Electronics(Product):
    def __init__(self, productId, productName, description, price, quantityInStock, productType, brand, warrantyPeriod):
        super().__init__(productId, productName, description, price, quantityInStock, productType)
        self._brand = brand
        self._warrantyPeriod = warrantyPeriod

    @property
    def brand(self):
        return self._brand

    @brand.setter
    def brand(self, value):
        self._brand = value

    @property
    def warrantyPeriod(self):
        return self._warrantyPeriod

    @warrantyPeriod.setter
    def warrantyPeriod(self, value):
        self._warrantyPeriod = value

electronics_product = Electronics(
    productId=1,
    productName="Laptop",
    description="High-performance laptop",
    price=999.99,
    quantityInStock=10,
    productType="Electronics",
    brand="XYZ",
    warrantyPeriod=12
)

print(electronics_product.productId)
print(electronics_product.productName)
print(electronics_product.description)
print(electronics_product.price)
print(electronics_product.quantityInStock)
print(electronics_product.productType)
print(electronics_product.brand)
print(electronics_product.warrantyPeriod)

class Clothing(Product):
    def __init__(self, productId, productName, description, price, quantityInStock, productType, size, color):
        super().__init__(productId, productName, description, price, quantityInStock, productType)
        self._size = size
        self._color = color

    @property
    def size(self):
        return self._size

    @size.setter
    def size(self, value):
        self._size = value

    @property
    def color(self):
        return self._color

    @color.setter
    def color(self, value):
        self._color = value

clothing_product = Clothing(
    productId=2,
    productName="T-Shirt",
    description="Comfortable cotton t-shirt",
    price=19.99,
    quantityInStock=50,
    productType="Clothing",
    size="Medium",
    color="Blue"
)

print(clothing_product.productId)
print(clothing_product.productName)
print(clothing_product.description)
print(clothing_product.price)
print(clothing_product.quantityInStock)
print(clothing_product.productType)
print(clothing_product.size)
print(clothing_product.color)


