from mysql.connector import connect


class DBUtil:
    def __init__(self, host, user, password, port, database):
        self.connection = connect(
            host=host,
            user=user,
            password=password,
            port=port,
            database=database
        )
        self.cursor = self.connection.cursor()

    def execute_query(self, query, values=None):
        try:
            self.cursor.execute(query, values)
            self.connection.commit()
            self.cursor.fetchall()
        except Exception as e:
            print(f"Query Execution Error! {e}")
            self.connection.rollback()

    def fetch_one(self, query, values=None):
        try:
            self.cursor.execute(query, values)
            result = self.cursor.fetchone()
            return result
        except Exception as e:
            print(f"FetchOne Error: {e}")
            self.connection.rollback()
            return None

    def close_connection(self):
        self.cursor.close()
        self.connection.close()

class UserNotFound(Exception):
    pass

class OrderNotFound(Exception):
    pass

from CodingChallenge.Service.IOrderManagementRepository import IOrderManagementRepository


class OrderProcessor(IOrderManagementRepository):
    def __init__(self):

        self.db_util = {}
        self.users_database = {}
        self.orders_database = {}
        self.products_database = {}
        self.admin_user = None

    def createOrder(self, user, products):
        if user.userId not in self.users_database:
            self.createUser(user)
        order_id = len(self.orders_database) + 1
        self.orders_database[order_id] = {'userId': user.userId, 'products': products}
        return order_id

    def cancelOrder(self, userId, orderId):
        if userId not in self.users_database:
            raise UserNotFound("User not found in the database.")
        if orderId not in self.orders_database:
            raise OrderNotFound("Order not found in the database.")
        del self.orders_database[orderId]

    def createProduct(self, adminUser, product):
        if adminUser != self.admin_user:
            raise UserNotFound("Admin user not found in the database.")
        product_id = len(self.products_database) + 1
        self.products_database[product_id] = product
        return product_id

    def createUser(self, user):
        self.users_database[user.userId] = user

    def getAllProducts(self):
        return list(self.products_database.values())

    def getOrderByUser(self, user):
        user_orders = [order for order in self.orders_database.values() if order['userId'] == user.userId]
        return user_orders


class OrderManagement:
    def __init__(self, order_processor):
        self.order_processor = order_processor

    def main(self):
        db_util = DBUtil(host='localhost', user='root', password='Root', port='3306', database='OrderManagementSystem')

        while True:
            print("\nMenu:")
            print("1. Create User")
            print("2. Create Product")
            print("3. Cancel Order")
            print("4. Get All Products")
            print("5. Get Order by User")
            print("6. Exit")

            choice = input("Enter your choice: ")

            if choice == '1':
                self.createUser()
            elif choice == '2':
                self.createProduct()
            elif choice == '3':
                self.cancelOrder()
            elif choice == '4':
                self.getAllProducts()
            elif choice == '5':
                self.getOrderByUser()
            elif choice == '6':
                print("Exiting...")
                break
            else:
                print("Invalid choice. Please try again.")

    def createUser(self):
        userId = int(input("Enter userId: "))
        username = input("Enter username: ")
        password = input("Enter password: ")
        role = input("Enter role (Admin/User): ")

        user = {'userId': userId, 'username': username, 'password': password, 'role': role}
        self.order_processor.create_user(user)
        print("User created successfully.")

    def createProduct(self):
        productId = int(input("Enter productId: "))
        productName = input("Enter productName: ")
        description = input("Enter description: ")
        price = float(input("Enter price: "))
        quantityInStock = int(input("Enter quantityInStock: "))
        productType = input("Enter type (Electronics/Clothing): ")

        product = {'productId': productId, 'productName': productName, 'description': description,
                   'price': price, 'quantityInStock': quantityInStock, 'productType': productType}
        self.order_processor.create_product(product)
        print("Product created successfully.")

    def cancelOrder(self):
        orderId = int(input("Enter orderId: "))
        userId = int(input("Enter userId: "))

        try:
            self.order_processor.cancel_order(userId, orderId)
            print("Order canceled successfully.")
        except:
            print("Order not found.")

    def getAllProducts(self):
        products = self.order_processor.get_all_products()
        print("All Products:")
        for product in products:
            print(product)

    def getOrderByUser(self):
        userId = int(input("Enter userId: "))

        user_orders = self.order_processor.get_order_by_user(userId)
        if user_orders:
            print("Orders for user:")
            for order in user_orders:
                print(order)
        else:
            print("No orders found for the user.")
