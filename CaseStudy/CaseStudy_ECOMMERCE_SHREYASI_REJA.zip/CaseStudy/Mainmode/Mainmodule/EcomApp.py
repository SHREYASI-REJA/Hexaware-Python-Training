from Dao.Service.Service import serviceprovider
from Entity.Model.Products import Product
from Entity.Model.Customers import Customer
from Myexception.Myexceptions.Exception import ProductNotFoundException,CustomerNotFoundException


class EcomApp:
    class EcomApp:

        @staticmethod
        def main():
            s = serviceprovider()
            while True:
                print("\n----------Main Menu----------")
                print("Enter-1 Add a new product")
                print("Enter-2 Register Customer")
                print("Enter-3 Delete Product")
                print("Enter-4 Add To Cart")
                print("Enter-5 Remove From Cart")
                print("Enter-6 View Cart")
                print("Enter-7 Place Order")
                print("Enter-8 Exit")

                ch = input("Enter your choice: ")

                if ch == '1':
                    product_name = input("Enter product name: ")
                    description = input("Enter description: ")
                    price = float(input("Enter price: "))
                    quantity = int(input("Enter stock quantity: "))
                    product_id = Product(product_name, price, description, quantity).create_product()
                    if product_id:
                        print("Product added successfully!")
                    else:
                        print("Failed to add product.")


                elif ch == '2':
                    name = input("Enter customer name: ")
                    password = input("Enter password: ")
                    if s.customer_exists(name, password) > 0:
                        print("Customer already exists")
                    else:
                        email = input("Enter email: ")
                        Customer(name, email, password).create_customer()

                elif ch == '3':
                    all_products = s.show_all_products()
                    if all_products is not None:
                        print("All Products:")
                        for product in all_products:
                            product_id, name, price, description, stock_quantity = product
                            print(
                                f"Product id:{product_id},Product Name: {name},Price: {price},Description: {description},Stock Quantity: {stock_quantity}")
                        product_id = input("Enter product id: ")
                        exists = s.product_exists(product_id)
                        if exists:
                            s.delete_product(product_id)
                        else:
                            raise ProductNotFoundException("Product does not exist.")
                    else:
                        print("Failed to retrieve products.")

                elif ch == '4':
                    customer_id = int(input("Enter customer id: "))
                    name = input("Enter customer name: ")
                    password = input("Enter password: ")
                    if s.customer_exists(name, password) > 0:
                        print("Customer login successfully")
                    else:
                        raise CustomerNotFoundException("Customer doesnot exist.")
                    all_products = s.show_all_products()
                    if all_products is not None:
                        print("All Products:")
                        for product in all_products:
                            product_id, name, price, description, stock_quantity = product
                            print(
                                f"Product ID: {product_id},Product Name: {name},Price: {price},Description: {description},Stock Quantity: {stock_quantity}")
                        product_id = int(input("Enter product id: "))
                        quantity = int(input("Enter quantity: "))
                        s.addToCart(customer_id, product_id, quantity)
                    else:
                        print("Failed to add product")

                elif ch == '5':
                    customer_id = int(input("Enter customer id: "))
                    name = input("Enter customer name: ")
                    password = input("Enter password: ")
                    if s.customer_exists(name, password) > 0:
                        print("Customer login successfully")
                    else:
                        raise CustomerNotFoundException("Customer doesnot exist.")
                    products_in_cart = s.getAllFromCart(customer_id)
                    if products_in_cart:
                        print("Products in Cart:")
                        for product in products_in_cart:
                            print(
                                f"Product id: {product[0]} , Product Name: {product[1]}, price: ${product[2]}, description:{product[3]}, quantity: {product[4]}")

                        product_id_to_remove = int(input("Enter product id to remove from cart: "))
                        success = s.removeFromCart(customer_id, product_id_to_remove)
                        if success:
                            print("Product removed from cart successfully!")
                        else:
                            print("Failed to remove product from cart.")
                    else:
                        print("No products in the cart.")

                elif ch == '6':
                    customer_id = int(input("Enter customer id: "))
                    name = input("Enter customer name: ")
                    password = input("Enter password: ")
                    if s.customer_exists(name, password) > 0:
                        print("Customer login successfully")
                    else:
                        raise CustomerNotFoundException("Customer doesnot exist.")
                    products_in_cart = s.getAllFromCart(customer_id)
                    if products_in_cart:
                        print("Products in Cart:")
                        for product in products_in_cart:
                            print(
                                f"Product id: {product[0]} , Product Name: {product[1]}, price: ${product[2]}, description:{product[3]}, quantity: {product[4]}")
                    else:
                        print("No products in the cart.")

                elif ch == '7':
                    customer_id = int(input("Enter customer id: "))
                    name = input("Enter customer name: ")
                    password = input("Enter password: ")
                    if s.customer_exists(name, password) > 0:
                        print("Customer login successfully")
                    else:
                        raise CustomerNotFoundException("Customer doesnot exist.")
                    shipping_address = input("Enter shipping address: ")
                    success = s.placeOrder(customer_id, shipping_address)
                    if success:
                        print("Order placed successfully!")
                    else:
                        print("Failed to place the order.")

                elif ch == '8':
                    print("Thank you")
                    break

                else:
                    print("Invalid choice. Please try again.")

    if __name__ == "__main__":
        EcomApp.main()