class PropertyUtil:
    def getPropertyString():
        host = 'localhost'
        username = 'root'
        password = 'Root'
        database = 'Ecommerce'
        return host, username, password, database