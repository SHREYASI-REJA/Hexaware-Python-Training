from Util.Connection.DBConnection import DBConnection
class Cart(DBConnection):
    def __init__(self, customer_id, product_id, quantity):
        self.customer_id = customer_id
        self.product_id = product_id
        self.quantity = quantity