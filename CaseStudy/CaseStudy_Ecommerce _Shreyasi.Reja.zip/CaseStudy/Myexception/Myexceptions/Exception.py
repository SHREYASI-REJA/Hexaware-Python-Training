class CustomerNotFoundException(Exception):
    pass

class ProductNotFoundException(Exception):
    pass

class OrderNotFoundException(Exception):
    pass
