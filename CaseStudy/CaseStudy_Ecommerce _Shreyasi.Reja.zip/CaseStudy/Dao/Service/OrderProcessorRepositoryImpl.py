from Dao.Service.OrderProcessorRepository import OrderProcessorRepository
from Myexception.Myexceptions.Exception import CustomerNotFoundException, ProductNotFoundException

class OrderProcessorRepositoryImpl(OrderProcessorRepository):
    def __init__(self):
        self.db_util = {}
        self.customers_database = {}
        self.products_database = {}
        self.cart_database = {}
        self.orders_database = {}
        self.order_items_database = {}

    def create_product(self, product):
        product_id = len(self.products_database) + 1
        self.products_database[product_id] = product
        return product_id

    def create_customer(self, customer):
        customer_id = len(self.customers_database) + 1
        self.customers_database[customer_id] = customer
        return customer_id

    def delete_product(self, product_id):
        if product_id not in self.products_database:
            raise ProductNotFoundException("Product not found in the database.")
        del self.products_database[product_id]

    def delete_customer(self, customer_id):
        if customer_id not in self.customers_database:
            raise CustomerNotFoundException("Customer not found in the database.")
        del self.customers_database[customer_id]

    def add_to_cart(self, customer, product, quantity):
        if product.productId not in self.products_database:
            raise ProductNotFoundException("Product not found in the database.")

        if customer.customerId not in self.cart_database:
            self.cart_database[customer.customerId] = {}

        if product.productId in self.cart_database[customer.customerId]:
            self.cart_database[customer.customerId][product.productId] += quantity
        else:
            self.cart_database[customer.customerId][product.productId] = quantity

    def remove_from_cart(self, customer, product):
        if customer.customerId not in self.cart_database or product.productId not in self.cart_database[
            customer.customerId]:
            raise ProductNotFoundException("Product not found in the cart.")

        del self.cart_database[customer.customerId][product.productId]

    def get_all_from_cart(self, customer):
        return self.cart_database.get(customer.customerId, {})

    def place_order(self, customer, products_quantities):
        order_id = len(self.orders_database) + 1
        self.orders_database[order_id] = {'customer_id': customer.customerId,
                                          'products_quantities': products_quantities}
        return order_id

    def get_orders_by_customer(self, customer_id):
        user_orders = [order for order in self.orders_database.values() if order['customer_id'] == customer_id]
        return user_orders
