from Dao.Service.OrderProcessorRepositoryImpl import OrderProcessorRepositoryImpl
from Util.Connection.DBConnection import DBUtil

class EcomApp:
    def __init__(self):
        self.order_processor = OrderProcessorRepositoryImpl()
        self.db_util = DBUtil(host='localhost', user='root', password='Root', port='3306', database='Ecommerce')

    def register_customer(self):
        try:
            connection = self.db_util.connection
            cursor = connection.cursor()

            customer_id = int(input("Enter customer ID: "))

            name = input("Enter customer name: ")
            email = input("Enter customer email: ")
            password = input("Enter customer password: ")

            query = "INSERT INTO customers (customer_id, name, email, password) VALUES (%s, %s, %s, %s)"
            cursor.execute(query, (customer_id, name, email, password))

            connection.commit()
            cursor.close()
            connection.close()

            print("Customer registered successfully!")
        except Exception as e:
            print(f"Error registering customer: {e}")

    def create_product(self):
        try:
            connection = self.db_util.connection
            cursor = connection.cursor()

            name = input("Enter product name: ")
            price = float(input("Enter product price: "))
            description = input("Enter product description: ")
            stock_quantity = int(input("Enter product stock quantity: "))

            query = "INSERT INTO products (name, price, description, stock_quantity) VALUES (%s, %s, %s, %s)"
            cursor.execute(query, (name, price, description, stock_quantity))

            connection.commit()
            cursor.close()
            connection.close()

            print("Product created successfully!")
        except Exception as e:
            print(f"Error creating product: {e}")

    def delete_product(self):
        try:
            connection = self.db_util.connection
            cursor = connection.cursor()

            product_id = int(input("Enter product ID to delete: "))

            query = "DELETE FROM products WHERE product_id = %s"
            cursor.execute(query, (product_id,))

            connection.commit()
            cursor.close()
            connection.close()

            print("Product deleted successfully!")
        except Exception as e:
            print(f"Error deleting product: {e}")

    def add_to_cart(self):
        try:
            connection = self.db_util.connection
            cursor = connection.cursor()

            customer_id = int(input("Enter customer ID: "))
            product_id = int(input("Enter product ID to add to cart: "))
            quantity = int(input("Enter quantity: "))

            query = "INSERT INTO cart (customer_id, product_id, quantity) VALUES (%s, %s, %s)"
            cursor.execute(query, (customer_id, product_id, quantity))

            connection.commit()
            cursor.close()
            connection.close()

            print("Product added to cart successfully!")
        except Exception as e:
            print(f"Error adding product to cart: {e}")

    def view_cart(self):
        try:
            connection = self.db_util.connection
            cursor = connection.cursor()

            customer_id = int(input("Enter customer ID to view cart: "))

            query = "SELECT product_id, quantity FROM cart WHERE customer_id = %s"
            cursor.execute(query, (customer_id,))
            cart = cursor.fetchall()

            print("Cart Contents:")
            for product_id, quantity in cart:
                print(f"Product ID: {product_id}, Quantity: {quantity}")

            cursor.close()
            connection.close()

        except Exception as e:
            print(f"Error viewing cart: {e}")

    def place_order(self):
        try:
            connection = self.db_util.connection
            cursor = connection.cursor()

            customer_id = int(input("Enter customer ID to place order: "))

            products_quantities = []
            while True:
                product_id = int(input("Enter product ID to order (enter -1 to finish): "))
                if product_id == -1:
                    break
                quantity = int(input("Enter quantity: "))
                products_quantities.append((product_id, quantity))

            query = "INSERT INTO orders (customer_id) VALUES (%s)"
            cursor.execute(query, (customer_id,))
            order_id = cursor.lastrowid

            for product_id, quantity in products_quantities:
                query = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (%s, %s, %s)"
                cursor.execute(query, (order_id, product_id, quantity))

            connection.commit()
            cursor.close()
            connection.close()

            print(f"Order placed successfully with ID: {order_id}")
        except Exception as e:
            print(f"Error placing order: {e}")

    def view_customer_order(self):
        try:
            connection = self.db_util.connection
            cursor = connection.cursor()

            customer_id = int(input("Enter customer ID to view orders: "))

            query = "SELECT order_id, product_id, quantity FROM order_items WHERE order_id IN (SELECT order_id FROM orders WHERE customer_id = %s)"
            cursor.execute(query, (customer_id,))
            orders = cursor.fetchall()

            print(f"Orders for Customer ID {customer_id}:")
            for order in orders:
                print(f"Order ID: {order[0]}, Product ID: {order[1]}, Quantity: {order[2]}")
            cursor.close()
            connection.close()

        except Exception as e:
            print(f"Error viewing customer orders: {e}")

    def main(self):
        while True:
            print("E-commerce Application Menu:")
            print("1. Register Customer")
            print("2. Create Product")
            print("3. Delete Product")
            print("4. Add to Cart")
            print("5. View Cart")
            print("6. Place Order")
            print("7. View Customer Order")
            print("8. Exit")

            choice = input("Enter your choice: ")

            if choice == '1':
                self.register_customer()
            elif choice == '2':
                self.create_product()
            elif choice == '3':
                self.delete_product()
            elif choice == '4':
                self.add_to_cart()
            elif choice == '5':
                self.view_cart()
            elif choice == '6':
                self.place_order()
            elif choice == '7':
                self.view_customer_order()
            elif choice == '8':
                print("Exiting the application.")
                break
            else:
                print("Invalid choice. Please choose a number from 1 to 8.")

if __name__ == "__main__":
    app = EcomApp()
    app.main()
