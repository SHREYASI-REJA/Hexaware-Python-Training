import unittest
from unittest.mock import patch
from Mainmode.Mainmodule.EcomApp import EcomApp
from Myexception.Myexceptions.Exception import CustomerNotFoundException

class TestEcommerceSystem(unittest.TestCase):
    def setUp(self):
        self.ecom_app = EcomApp()

    @patch('builtins.input', side_effect=["Test Product", 100, "Test Description", 50])
    def test_product_created_successfully(self, mock_inputs):
        self.assertTrue(self.ecom_app.create_product())

    @patch('builtins.input', side_effect=["1", "1", "5"])
    def test_product_added_to_cart_successfully(self, mock_inputs):
        self.assertTrue(self.ecom_app.add_to_cart())

    @patch('builtins.input', side_effect=["1", "1", "5"])
    def test_product_ordered_successfully(self, mock_inputs):
        self.assertTrue(self.ecom_app.place_order())

    def test_customer_id_not_found_exception(self):
        with self.assertRaises(CustomerNotFoundException):
            self.ecom_app.view_customer_order()

if __name__ == '__main__':
    unittest.main()
